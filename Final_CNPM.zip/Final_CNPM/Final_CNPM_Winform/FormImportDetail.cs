﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Final_CNPM_Winform
{
    public partial class FormImportDetail : Form
    {
        String strConn = ConfigurationManager.ConnectionStrings["SQLConnection"].ConnectionString;
        private readonly  MainForm frmMain = new MainForm();
        public FormImportDetail(String id)
        {
            InitializeComponent();
            LoadTable(id);
            LoadData(id);
            lbl_ID.Text = id;
        }
        private void LoadTable(String id)
        {
            DataTable tbl = new DataTable();
            SqlConnection conn = new SqlConnection(strConn);
            conn.Open();
            SqlCommand command=conn.CreateCommand();
            command.CommandText = "select a.IM_DE_ID, a.IM_ORDER_ID,b.PRODUCT_NAME ,a.QUANTITY from IMPORT_DETAIL a inner join PRODUCT b on a.PRO_ID=b.PRODUCT_ID where IM_ORDER_ID=@id";
            command.Parameters.AddWithValue("@id", id);
            SqlDataAdapter dapter=new SqlDataAdapter(command);
            dapter.Fill(tbl);
            if (tbl.Rows.Count > 0)
            {
                dtgImportDetail.DataSource = tbl;
                dtgImportDetail.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                dtgImportDetail.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                dtgImportDetail.Columns[3].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            }
        }

        private void LoadData(String id)
        {
            DataTable tbl = new DataTable();
            SqlConnection conn = new SqlConnection(strConn);
            conn.Open();
            SqlCommand command = conn.CreateCommand();
            command.CommandText = "SELECT * FROM IMPORT_ORDER WHERE IM_OR_ID=@id";
            command.Parameters.AddWithValue("@id", id);
            SqlDataAdapter dapter = new SqlDataAdapter(command);
            dapter.Fill(tbl);
            txtPayment.Text = Label(tbl.Rows[0]["PAYMENT_ID"].ToString());
        }
        private String Label(String method)
        {
            DataTable tbl = new DataTable();
            SqlConnection conn = new SqlConnection(strConn);
            conn.Open();
            SqlCommand command = conn.CreateCommand();
            command.CommandText = "SELECT PAYMENT_NAME FROM PAYMENT_METHOD WHERE PAYMENT_ID=@method";
            command.Parameters.AddWithValue("@method", method);
            SqlDataAdapter dapter = new SqlDataAdapter(command);
            dapter.Fill(tbl);
            return tbl.Rows[0]["PAYMENT_NAME"].ToString();
        }

       

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            UpdateStatus(cbStatus.SelectedItem.ToString());
            frmMain.ReloadImport();
            Dispose();
            
        }
        private void UpdateStatus(String status)
        {
           
            SqlConnection conn = new SqlConnection(strConn);
            try
            {
                conn.Open();
                SqlCommand command = conn.CreateCommand();
                command.CommandText = "UPDATE IMPORT_ORDER SET IMPORT_STATUS = @status WHERE IM_OR_ID=@id";
                command.Parameters.AddWithValue("@status", status);
                command.Parameters.AddWithValue("@id", lbl_ID.Text.ToString());
                command.ExecuteNonQuery();
                MessageBox.Show("Success");
             
            }
            catch (Exception ex)
            {
                MessageBox.Show("Cannot Update this");
            }
            finally
            {
                conn.Close();
            }
      
        }
    }
}
