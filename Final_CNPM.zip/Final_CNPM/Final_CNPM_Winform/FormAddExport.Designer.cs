﻿namespace Final_CNPM_Winform
{
    partial class FormAddExport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtDetailId = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtOrderID = new System.Windows.Forms.TextBox();
            this.cbPaymentMethod = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.cbProduct = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.dtImport = new System.Windows.Forms.DateTimePicker();
            this.label5 = new System.Windows.Forms.Label();
            this.cbAgent = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.btnCreate = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.dtgPro = new System.Windows.Forms.DataGridView();
            this.ExDeId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ExOrID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PRODUCT_NAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Quantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Delete = new System.Windows.Forms.DataGridViewButtonColumn();
            this.nbQuantity = new System.Windows.Forms.NumericUpDown();
            this.label7 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dtgPro)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nbQuantity)).BeginInit();
            this.SuspendLayout();
            // 
            // txtDetailId
            // 
            this.txtDetailId.Location = new System.Drawing.Point(181, 24);
            this.txtDetailId.Name = "txtDetailId";
            this.txtDetailId.Size = new System.Drawing.Size(161, 22);
            this.txtDetailId.TabIndex = 31;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(46, 24);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(97, 16);
            this.label3.TabIndex = 30;
            this.label3.Text = "Export Detail Id";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(46, 67);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(96, 16);
            this.label1.TabIndex = 32;
            this.label1.Text = "Export Order Id";
            // 
            // txtOrderID
            // 
            this.txtOrderID.Location = new System.Drawing.Point(181, 67);
            this.txtOrderID.Name = "txtOrderID";
            this.txtOrderID.Size = new System.Drawing.Size(161, 22);
            this.txtOrderID.TabIndex = 33;
            // 
            // cbPaymentMethod
            // 
            this.cbPaymentMethod.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbPaymentMethod.FormattingEnabled = true;
            this.cbPaymentMethod.Location = new System.Drawing.Point(501, 64);
            this.cbPaymentMethod.Margin = new System.Windows.Forms.Padding(4);
            this.cbPaymentMethod.Name = "cbPaymentMethod";
            this.cbPaymentMethod.Size = new System.Drawing.Size(193, 24);
            this.cbPaymentMethod.TabIndex = 37;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(385, 70);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(108, 16);
            this.label4.TabIndex = 36;
            this.label4.Text = "Payment Method";
            // 
            // cbProduct
            // 
            this.cbProduct.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbProduct.FormattingEnabled = true;
            this.cbProduct.Location = new System.Drawing.Point(501, 13);
            this.cbProduct.Margin = new System.Windows.Forms.Padding(4);
            this.cbProduct.Name = "cbProduct";
            this.cbProduct.Size = new System.Drawing.Size(193, 24);
            this.cbProduct.TabIndex = 35;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(430, 18);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 16);
            this.label2.TabIndex = 34;
            this.label2.Text = "Product";
            // 
            // dtImport
            // 
            this.dtImport.CustomFormat = "yyyy/MM/dd";
            this.dtImport.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtImport.Location = new System.Drawing.Point(804, 61);
            this.dtImport.Margin = new System.Windows.Forms.Padding(4);
            this.dtImport.Name = "dtImport";
            this.dtImport.Size = new System.Drawing.Size(193, 22);
            this.dtImport.TabIndex = 39;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(733, 67);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(36, 16);
            this.label5.TabIndex = 38;
            this.label5.Text = "Date";
            // 
            // cbAgent
            // 
            this.cbAgent.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbAgent.FormattingEnabled = true;
            this.cbAgent.Location = new System.Drawing.Point(804, 10);
            this.cbAgent.Margin = new System.Windows.Forms.Padding(4);
            this.cbAgent.Name = "cbAgent";
            this.cbAgent.Size = new System.Drawing.Size(193, 24);
            this.cbAgent.TabIndex = 41;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(733, 15);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(42, 16);
            this.label6.TabIndex = 40;
            this.label6.Text = "Agent";
            // 
            // btnCreate
            // 
            this.btnCreate.Location = new System.Drawing.Point(1079, 70);
            this.btnCreate.Margin = new System.Windows.Forms.Padding(4);
            this.btnCreate.Name = "btnCreate";
            this.btnCreate.Size = new System.Drawing.Size(123, 28);
            this.btnCreate.TabIndex = 43;
            this.btnCreate.Text = "Create Order";
            this.btnCreate.UseVisualStyleBackColor = true;
            this.btnCreate.Click += new System.EventHandler(this.btnCreate_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(1079, 13);
            this.btnAdd.Margin = new System.Windows.Forms.Padding(4);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(123, 28);
            this.btnAdd.TabIndex = 42;
            this.btnAdd.Text = "Add Product";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // dtgPro
            // 
            this.dtgPro.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgPro.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ExDeId,
            this.ExOrID,
            this.PRODUCT_NAME,
            this.Quantity,
            this.Delete});
            this.dtgPro.Location = new System.Drawing.Point(12, 182);
            this.dtgPro.Name = "dtgPro";
            this.dtgPro.RowHeadersWidth = 51;
            this.dtgPro.RowTemplate.Height = 24;
            this.dtgPro.Size = new System.Drawing.Size(1209, 376);
            this.dtgPro.TabIndex = 44;
            this.dtgPro.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgPro_CellContentClick);
            // 
            // ExDeId
            // 
            this.ExDeId.HeaderText = "Export Detail Id";
            this.ExDeId.MinimumWidth = 6;
            this.ExDeId.Name = "ExDeId";
            this.ExDeId.Width = 125;
            // 
            // ExOrID
            // 
            this.ExOrID.HeaderText = "Export Order ID";
            this.ExOrID.MinimumWidth = 6;
            this.ExOrID.Name = "ExOrID";
            this.ExOrID.Width = 125;
            // 
            // PRODUCT_NAME
            // 
            this.PRODUCT_NAME.HeaderText = "ProductName";
            this.PRODUCT_NAME.MinimumWidth = 6;
            this.PRODUCT_NAME.Name = "PRODUCT_NAME";
            this.PRODUCT_NAME.Width = 125;
            // 
            // Quantity
            // 
            this.Quantity.HeaderText = "Quantity";
            this.Quantity.MinimumWidth = 6;
            this.Quantity.Name = "Quantity";
            this.Quantity.Width = 125;
            // 
            // Delete
            // 
            this.Delete.HeaderText = "Delete";
            this.Delete.MinimumWidth = 6;
            this.Delete.Name = "Delete";
            this.Delete.Text = "Delete";
            this.Delete.UseColumnTextForButtonValue = true;
            this.Delete.Width = 125;
            // 
            // nbQuantity
            // 
            this.nbQuantity.Location = new System.Drawing.Point(804, 112);
            this.nbQuantity.Margin = new System.Windows.Forms.Padding(4);
            this.nbQuantity.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nbQuantity.Name = "nbQuantity";
            this.nbQuantity.Size = new System.Drawing.Size(193, 22);
            this.nbQuantity.TabIndex = 46;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(733, 114);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(55, 16);
            this.label7.TabIndex = 45;
            this.label7.Text = "Quantity";
            // 
            // FormAddExport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1224, 570);
            this.Controls.Add(this.nbQuantity);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.dtgPro);
            this.Controls.Add(this.btnCreate);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.cbAgent);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.dtImport);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.cbPaymentMethod);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.cbProduct);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtOrderID);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtDetailId);
            this.Controls.Add(this.label3);
            this.Name = "FormAddExport";
            this.Text = "FormAddExport";
            ((System.ComponentModel.ISupportInitialize)(this.dtgPro)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nbQuantity)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtDetailId;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtOrderID;
        private System.Windows.Forms.ComboBox cbPaymentMethod;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cbProduct;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker dtImport;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cbAgent;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnCreate;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.DataGridView dtgPro;
        private System.Windows.Forms.DataGridViewTextBoxColumn ExDeId;
        private System.Windows.Forms.DataGridViewTextBoxColumn ExOrID;
        private System.Windows.Forms.DataGridViewTextBoxColumn PRODUCT_NAME;
        private System.Windows.Forms.DataGridViewTextBoxColumn Quantity;
        private System.Windows.Forms.DataGridViewButtonColumn Delete;
        private System.Windows.Forms.NumericUpDown nbQuantity;
        private System.Windows.Forms.Label label7;
    }
}