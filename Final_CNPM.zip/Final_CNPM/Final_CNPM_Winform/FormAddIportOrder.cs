﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Final_CNPM_Winform
{
        
    public partial class FormAddIportOrder : Form
    {
        String strConn = ConfigurationManager.ConnectionStrings["SQLConnection"].ConnectionString;
        public FormAddIportOrder()
        {
            InitializeComponent();
            ReloadPayment();
            ReloadProduct();
        }

        private void FormAddIportOrder_Load(object sender, EventArgs e)
        {

        }
        private void ReloadPayment()
        {
            SqlConnection conn=new SqlConnection(strConn);
            DataTable dt = new DataTable();
            try
            {
                conn.Open();
                SqlCommand cmd=conn.CreateCommand();
                cmd.CommandText = "SELECT PAYMENT_NAME FROM PAYMENT_METHOD";
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                adapter.Fill(dt);
                cbPaymentMethod.DataSource= dt;
                cbPaymentMethod.DisplayMember = "PAYMENT_NAME";
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();
            }

        }
        private void ReloadProduct()
        {
            SqlConnection conn = new SqlConnection(strConn);
            DataTable dt = new DataTable();
            try
            {
                conn.Open();
                SqlCommand cmd = conn.CreateCommand();
                cmd.CommandText = "SELECT PRODUCT_NAME FROM PRODUCT";
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                adapter.Fill(dt);
                cbProduct.DataSource = dt;                
                cbProduct.DisplayMember = "PRODUCT_NAME";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            //MessageBox.Show("|"+cbPaymentMethod.Text.ToString()+"|");
            if (nbQuantity.Value == 0)
            {
                MessageBox.Show("Invalid Quantity");
                return;
            }
            foreach(DataGridViewRow row in dtgPro.Rows)
            {
                if (row.Cells["PRODUCT_NAME"].Value == cbProduct.SelectedValue)
                {
                    MessageBox.Show("Product existed");
                }
            }
            dtgPro.Rows.Add(txtDetailId.Text,cbProduct.Text,nbQuantity.Value);
        }

        private void dtgPro_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if(e.RowIndex>=0&& e.ColumnIndex == Delete.Index)
            {
                dtgPro.Rows.RemoveAt(e.RowIndex);
            }
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            String name=cbPaymentMethod.Text.ToString();
            String pay_method=getIdByName(name);
            String order_id = txtOrderID.Text.ToString();
            String date = dtImport.Text.ToString();
            String status = "Chua thanh toan";
            if (addImportOrder(order_id, date, pay_method, status))
            {
                MessageBox.Show("success");
            }
            foreach(DataGridViewRow item in dtgPro.Rows)
            {
                String pro_id = getProductId(item.Cells["PRODUCT_NAME"].Value.ToString());
                String detail_id = item.Cells["ImDeId"].Value.ToString();
                String quantity = item.Cells["Quantity"].Value.ToString();
                if (addImportDetail(detail_id, order_id, pro_id, quantity))
                {
                    MessageBox.Show("add success "+detail_id);
                }
            }
        }


        private bool addImportDetail(String detail_id,String order_id,String pro_id,String quantity)
        {
            bool result = false;
            SqlConnection conn = new SqlConnection(strConn);
            try
            {
                conn.Open();
                SqlCommand command = conn.CreateCommand();
                command.CommandText = "INSERT INTO IMPORT_DETAIL VALUES(@detail_id, @order_id,@pro_id,@quantity)";
                command.Parameters.AddWithValue("@order_id", order_id);
                command.Parameters.AddWithValue("@detail_id", detail_id);
                command.Parameters.AddWithValue("@pro_id", pro_id);
                command.Parameters.AddWithValue("@quantity", quantity);
                command.ExecuteNonQuery();
                result = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();
            }

            return result;
        }

        private bool addImportOrder(String order_id,String date,String pay_method,String status)
        {
            bool result = false;
            SqlConnection conn = new SqlConnection(strConn);
            try
            {
                conn.Open();
                SqlCommand command = conn.CreateCommand();
                command.CommandText = "INSERT INTO IMPORT_ORDER VALUES(@order_id, @date,@pay_method,@status)";
                command.Parameters.AddWithValue("@order_id", order_id);
                command.Parameters.AddWithValue("@date", date);
                command.Parameters.AddWithValue("@pay_method", pay_method);
                command.Parameters.AddWithValue("@status", status);
                command.ExecuteNonQuery();
                result = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();
            }

            return result;
        }
         

        private String getProductId(String name)
        {
            String result = "";
            SqlConnection conn = new SqlConnection(strConn);
            DataTable dt = new DataTable();
            try
            {
                conn.Open();
                SqlCommand cmd = conn.CreateCommand();
                cmd.CommandText = "SELECT PRODUCT_ID FROM PRODUCT WHERE PRODUCT_NAME=@Name";
                cmd.Parameters.AddWithValue("@Name", name);
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                adapter.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    result = dt.Rows[0]["PRODUCT_ID"].ToString();

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();
            }

            return result;

        }


        private String getIdByName(String name)
        {
            String result = "";
            SqlConnection conn = new SqlConnection(strConn);
            DataTable dt = new DataTable();
            try
            {
                conn.Open();
                SqlCommand cmd = conn.CreateCommand();
                cmd.CommandText = "SELECT PAYMENT_ID FROM PAYMENT_METHOD WHERE PAYMENT_NAME=@Name";
                cmd.Parameters.AddWithValue("@Name", name);
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                adapter.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                result =dt.Rows[0]["PAYMENT_ID"].ToString();

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();
            }

            return result;
        }

    }
}
