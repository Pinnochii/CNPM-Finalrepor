﻿namespace Final_CNPM_Winform
{
    partial class FormImportDetail
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dtgImportDetail = new System.Windows.Forms.DataGridView();
            this.DetailId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ImOrId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Quanti = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.l = new System.Windows.Forms.Label();
            this.txtPayment = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.cbStatus = new System.Windows.Forms.ComboBox();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.lbl_ID = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dtgImportDetail)).BeginInit();
            this.SuspendLayout();
            // 
            // dtgImportDetail
            // 
            this.dtgImportDetail.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgImportDetail.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.DetailId,
            this.ImOrId,
            this.ProName,
            this.Quanti});
            this.dtgImportDetail.Location = new System.Drawing.Point(22, 111);
            this.dtgImportDetail.Name = "dtgImportDetail";
            this.dtgImportDetail.RowHeadersWidth = 51;
            this.dtgImportDetail.RowTemplate.Height = 24;
            this.dtgImportDetail.Size = new System.Drawing.Size(923, 407);
            this.dtgImportDetail.TabIndex = 0;
            // 
            // DetailId
            // 
            this.DetailId.DataPropertyName = "IM_DE_ID";
            this.DetailId.HeaderText = "Id";
            this.DetailId.MinimumWidth = 6;
            this.DetailId.Name = "DetailId";
            this.DetailId.Width = 125;
            // 
            // ImOrId
            // 
            this.ImOrId.DataPropertyName = "IM_ORDER_ID";
            this.ImOrId.HeaderText = "Import Order Id";
            this.ImOrId.MinimumWidth = 6;
            this.ImOrId.Name = "ImOrId";
            this.ImOrId.Width = 125;
            // 
            // ProName
            // 
            this.ProName.DataPropertyName = "PRODUCT_NAME";
            this.ProName.HeaderText = "Product Name";
            this.ProName.MinimumWidth = 6;
            this.ProName.Name = "ProName";
            this.ProName.Width = 125;
            // 
            // Quanti
            // 
            this.Quanti.DataPropertyName = "QUANTITY";
            this.Quanti.HeaderText = "Quantity";
            this.Quanti.MinimumWidth = 6;
            this.Quanti.Name = "Quanti";
            this.Quanti.Width = 125;
            // 
            // l
            // 
            this.l.AutoSize = true;
            this.l.Location = new System.Drawing.Point(53, 66);
            this.l.Name = "l";
            this.l.Size = new System.Drawing.Size(114, 16);
            this.l.TabIndex = 5;
            this.l.Text = "Payment Method: ";
            // 
            // txtPayment
            // 
            this.txtPayment.AutoSize = true;
            this.txtPayment.Location = new System.Drawing.Point(184, 66);
            this.txtPayment.Name = "txtPayment";
            this.txtPayment.Size = new System.Drawing.Size(52, 16);
            this.txtPayment.TabIndex = 6;
            this.txtPayment.Text = "method";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(439, 74);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(90, 16);
            this.label4.TabIndex = 7;
            this.label4.Text = "Import Status: ";
            // 
            // cbStatus
            // 
            this.cbStatus.FormattingEnabled = true;
            this.cbStatus.Items.AddRange(new object[] {
            "Đã thanh toán",
            "Chưa thanh toán"});
            this.cbStatus.Location = new System.Drawing.Point(557, 66);
            this.cbStatus.Name = "cbStatus";
            this.cbStatus.Size = new System.Drawing.Size(172, 24);
            this.cbStatus.TabIndex = 8;
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(847, 66);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(75, 23);
            this.btnUpdate.TabIndex = 9;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(53, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(23, 16);
            this.label1.TabIndex = 10;
            this.label1.Text = "ID:";
            // 
            // lbl_ID
            // 
            this.lbl_ID.AutoSize = true;
            this.lbl_ID.Location = new System.Drawing.Point(91, 25);
            this.lbl_ID.Name = "lbl_ID";
            this.lbl_ID.Size = new System.Drawing.Size(18, 16);
            this.lbl_ID.TabIndex = 11;
            this.lbl_ID.Text = "id";
            // 
            // FormImportDetail
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(964, 517);
            this.Controls.Add(this.lbl_ID);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.cbStatus);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtPayment);
            this.Controls.Add(this.l);
            this.Controls.Add(this.dtgImportDetail);
            this.Name = "FormImportDetail";
            this.Text = "FormImportDetail";
            ((System.ComponentModel.ISupportInitialize)(this.dtgImportDetail)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dtgImportDetail;
        private System.Windows.Forms.Label l;
        private System.Windows.Forms.Label txtPayment;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cbStatus;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.DataGridViewTextBoxColumn DetailId;
        private System.Windows.Forms.DataGridViewTextBoxColumn ImOrId;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Quanti;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbl_ID;
    }
}