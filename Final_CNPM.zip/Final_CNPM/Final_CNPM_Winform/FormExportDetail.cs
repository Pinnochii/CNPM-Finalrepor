﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Final_CNPM_Winform
{
    public partial class FormExportDetail : Form
    {
        String strConn = ConfigurationManager.ConnectionStrings["SQLConnection"].ConnectionString;
        private readonly MainForm mainForm = new MainForm();
        public FormExportDetail(String id)
        {
            InitializeComponent();
            loadTable(id);
            loadData(id);
            txtExID.Text = id;
            //lblCustomerName.Text = getAgent("AGT6");
        }
        private void loadTable(String id)
        {
            DataTable tbl = new DataTable();
            SqlConnection conn = new SqlConnection(strConn);
            conn.Open();
            SqlCommand command = conn.CreateCommand();
            command.CommandText = "select a.EX_DE_ID, a.EX_ORDER_ID,b.PRODUCT_NAME ,a.QUANTITY from EXPORT_DETAIL a inner join PRODUCT b on a.PRO_ID=b.PRODUCT_ID where EX_ORDER_ID=@id";
            command.Parameters.AddWithValue("@id", id);
            SqlDataAdapter dapter = new SqlDataAdapter(command);
            dapter.Fill(tbl);
            if (tbl.Rows.Count > 0)
            {
                dtgExport.DataSource = tbl;
                dtgExport.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                dtgExport.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                dtgExport.Columns[3].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            }
        }
        private void loadData(String id)
        {
            DataTable tbl = new DataTable();
            SqlConnection conn = new SqlConnection(strConn);
            conn.Open();
            SqlCommand command = conn.CreateCommand();
            command.CommandText = "SELECT * FROM EXPORT_ORDER WHERE EXPORT_ID=@id";
            command.Parameters.AddWithValue("@id", id);
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            adapter.Fill(tbl);
            lblCustomerName.Text = getAgent(tbl.Rows[0]["AGENT_ID"].ToString());
            lblPaymentMethod.Text = getPayment(tbl.Rows[0]["PAYMENT_ID"].ToString());
        }


        private void UpdateStatus(String status)
        {

            SqlConnection conn = new SqlConnection(strConn);
            try
            {
                conn.Open();
                SqlCommand command = conn.CreateCommand();
                command.CommandText = "UPDATE EXPORT_ORDER SET ORDER_STATUS = @status WHERE EXPORT_ID=@id";
                command.Parameters.AddWithValue("@status", status);
                command.Parameters.AddWithValue("@id",cbPaymentStatus.Text.ToString());
                command.ExecuteNonQuery();
                MessageBox.Show("Success");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();
            }

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            UpdateStatus(cbPaymentStatus.SelectedItem.ToString());
            mainForm.ReloadExport();
            Dispose();
        }

        private String getAgent(String id)
        {
            String result = "";
            SqlConnection conn = new SqlConnection(strConn);
            DataTable dt = new DataTable();
            try
            {
                conn.Open();
                SqlCommand cmd = conn.CreateCommand();
                cmd.CommandText = "SELECT AGENT_NAME FROM AGENT WHERE AGENT_ID=@Name";
                cmd.Parameters.AddWithValue("@Name", id);
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                adapter.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    result = dt.Rows[0]["AGENT_NAME"].ToString();
                    
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();
            }

            return result;
        }
        private String getPayment(String id)
        {
            String result = "";
            SqlConnection conn = new SqlConnection(strConn);
            DataTable dt = new DataTable();
            try
            {
                conn.Open();
                SqlCommand cmd = conn.CreateCommand();
                cmd.CommandText = "SELECT PAYMENT_NAME FROM PAYMENT_METHOD WHERE PAYMENT_ID=@Name";
                cmd.Parameters.AddWithValue("@Name", id);
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                adapter.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    result = dt.Rows[0]["PAYMENT_NAME"].ToString();

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();
            }

            return result;
        }
    }
}
