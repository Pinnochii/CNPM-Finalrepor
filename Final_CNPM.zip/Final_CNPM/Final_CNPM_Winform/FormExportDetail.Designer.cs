﻿namespace Final_CNPM_Winform
{
    partial class FormExportDetail
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblCustomerName = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.cbPaymentStatus = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblPaymentMethod = new System.Windows.Forms.Label();
            this.dtgExport = new System.Windows.Forms.DataGridView();
            this.colExDeId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ExOrID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Quantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label2 = new System.Windows.Forms.Label();
            this.txtExID = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dtgExport)).BeginInit();
            this.SuspendLayout();
            // 
            // lblCustomerName
            // 
            this.lblCustomerName.AutoSize = true;
            this.lblCustomerName.Location = new System.Drawing.Point(384, 25);
            this.lblCustomerName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCustomerName.Name = "lblCustomerName";
            this.lblCustomerName.Size = new System.Drawing.Size(77, 16);
            this.lblCustomerName.TabIndex = 52;
            this.lblCustomerName.Text = "Khách hàng";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(217, 25);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(45, 16);
            this.label3.TabIndex = 51;
            this.label3.Text = "Agent:";
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(780, 88);
            this.btnUpdate.Margin = new System.Windows.Forms.Padding(4);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(100, 28);
            this.btnUpdate.TabIndex = 50;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // cbPaymentStatus
            // 
            this.cbPaymentStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbPaymentStatus.FormattingEnabled = true;
            this.cbPaymentStatus.Items.AddRange(new object[] {
            "Chưa thanh toán",
            "Đã than toán"});
            this.cbPaymentStatus.Location = new System.Drawing.Point(767, 25);
            this.cbPaymentStatus.Margin = new System.Windows.Forms.Padding(4);
            this.cbPaymentStatus.Name = "cbPaymentStatus";
            this.cbPaymentStatus.Size = new System.Drawing.Size(160, 24);
            this.cbPaymentStatus.TabIndex = 47;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(678, 25);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 16);
            this.label1.TabIndex = 46;
            this.label1.Text = "Status";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(217, 77);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(108, 16);
            this.label4.TabIndex = 44;
            this.label4.Text = "Payment method";
            // 
            // lblPaymentMethod
            // 
            this.lblPaymentMethod.AutoSize = true;
            this.lblPaymentMethod.Location = new System.Drawing.Point(387, 77);
            this.lblPaymentMethod.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPaymentMethod.Name = "lblPaymentMethod";
            this.lblPaymentMethod.Size = new System.Drawing.Size(74, 16);
            this.lblPaymentMethod.TabIndex = 45;
            this.lblPaymentMethod.Text = "Thanh toán";
            // 
            // dtgExport
            // 
            this.dtgExport.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgExport.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colExDeId,
            this.ExOrID,
            this.ProName,
            this.Quantity});
            this.dtgExport.Location = new System.Drawing.Point(17, 133);
            this.dtgExport.Name = "dtgExport";
            this.dtgExport.RowHeadersWidth = 51;
            this.dtgExport.RowTemplate.Height = 24;
            this.dtgExport.Size = new System.Drawing.Size(994, 398);
            this.dtgExport.TabIndex = 55;
            // 
            // colExDeId
            // 
            this.colExDeId.DataPropertyName = "EX_DE_ID";
            this.colExDeId.HeaderText = "ID";
            this.colExDeId.MinimumWidth = 6;
            this.colExDeId.Name = "colExDeId";
            this.colExDeId.Width = 125;
            // 
            // ExOrID
            // 
            this.ExOrID.DataPropertyName = "EX_ORDER_ID";
            this.ExOrID.HeaderText = "Order ID";
            this.ExOrID.MinimumWidth = 6;
            this.ExOrID.Name = "ExOrID";
            this.ExOrID.Width = 125;
            // 
            // ProName
            // 
            this.ProName.DataPropertyName = "PRODUCT_NAME";
            this.ProName.HeaderText = "Product Name";
            this.ProName.MinimumWidth = 6;
            this.ProName.Name = "ProName";
            this.ProName.Width = 125;
            // 
            // Quantity
            // 
            this.Quantity.DataPropertyName = "QUANTITY";
            this.Quantity.HeaderText = "Quantity";
            this.Quantity.MinimumWidth = 6;
            this.Quantity.Name = "Quantity";
            this.Quantity.Width = 125;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(45, 25);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(23, 16);
            this.label2.TabIndex = 56;
            this.label2.Text = "ID:";
            // 
            // txtExID
            // 
            this.txtExID.AutoSize = true;
            this.txtExID.Location = new System.Drawing.Point(111, 25);
            this.txtExID.Name = "txtExID";
            this.txtExID.Size = new System.Drawing.Size(18, 16);
            this.txtExID.TabIndex = 57;
            this.txtExID.Text = "id";
            // 
            // FormExportDetail
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1023, 543);
            this.Controls.Add(this.txtExID);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dtgExport);
            this.Controls.Add(this.lblCustomerName);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.cbPaymentStatus);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lblPaymentMethod);
            this.Name = "FormExportDetail";
            this.Text = "FormExportDetail";
            ((System.ComponentModel.ISupportInitialize)(this.dtgExport)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblCustomerName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.ComboBox cbPaymentStatus;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblPaymentMethod;
        private System.Windows.Forms.DataGridView dtgExport;
        private System.Windows.Forms.DataGridViewTextBoxColumn colExDeId;
        private System.Windows.Forms.DataGridViewTextBoxColumn ExOrID;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Quantity;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label txtExID;
    }
}